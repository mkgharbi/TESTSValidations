import os
import io
import unittest
from unittest.mock import Mock
from BST import BST, node


class TestBST(unittest.TestCase):

    def setUp(self):
        self.bst = BST()

    #4.1 for insert and print : 
    # Insert : 

    # Note: Nous considerons a priori que l'arbre est bien trier par la fonction insert. Dans le cas contraire, nos test 
    # echoueront pas défaut et la verification du triage de l'arbre est rondondante et inutile.

    #B1:
    def test_insert_node_when_BST_is_empty_root_will_be_the_inserted_node(self):
        self.bst.insert(1)
        self.assertEqual(self.bst.root.value, 1)

    #B2N1:
    def test_insert_node_when_BST_only_has_root_and_node_is_equal_to_root(self):
        self.bst.insert(1)
        self.bst.insert(1)
        self.assertEqual(self.bst.root.value, 1)
        self.assertIsNone(self.bst.root.left)
        self.assertIsNone(self.bst.root.right)

    #B2N2S1:
    def test_insert_node_when_BST_is_not_empty_and_node_greater_than_the_root(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.insert(3)
        self.assertEqual(self.bst.root.value, 2)
        self.assertEqual(self.bst.root.right.value, 3)

    #B2N3S1:
    def test_insert_node_when_BST_is_not_empty_and_node_lesser_than_the_root(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.insert(3)
        self.assertEqual(self.bst.root.value, 2)
        self.assertEqual(self.bst.root.left.value, 1)

    #B2N2S2 et B2N3S2 (Nous avons combiné ces cas de tests pour réduire la redondance):
    def test_insert_node_when_BST_is_not_empty_and_has_at_least_one_subtree(self):
        self.bst.insert(5)
        self.bst.insert(3)
        self.bst.insert(7)
        self.bst.insert(2)
        self.bst.insert(4)
        self.bst.insert(6)
        self.bst.insert(8)
        self.assertEqual(self.bst.root.value, 5)
        self.assertEqual(self.bst.root.right.right.value, 8)
        self.assertEqual(self.bst.root.left.left.value, 2)

    # Print :
     
    # Note: Nous considerons a priori que l'arbre est bien trier par la fonction insert

    @unittest.mock.patch('sys.stdout', new_callable=io.StringIO)
    def assert_stdout(self, expected_output, mock_stdout):
        self.bst.print_tree()
        self.assertEqual(mock_stdout.getvalue(), expected_output)
    
    #B1
    def test_print_tree_when_BST_is_empty(self):
        self.assert_stdout('')

    #B2
    def test_print_tree_when_BST_contains_only_the_root(self):
        self.bst.insert(2)
        self.assert_stdout('2\n')

    #B3
    def test_print_tree_when_BST_contains_two_nodes(self):
        self.bst.insert(2)
        self.bst.insert(3)
        self.assert_stdout('2\n3\n')
    
    #B4
    def test_print_tree_when_BST_contains_three_nodes(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.insert(3)
        self.assert_stdout('1\n2\n3\n')
    
    #B5
    def test_print_tree_when_BST_contains_more_than_three_nodes(self):
        self.bst.insert(5)
        self.bst.insert(3)
        self.bst.insert(7)
        self.bst.insert(2)
        self.bst.insert(4)
        self.bst.insert(6)
        self.bst.insert(8)
        self.assert_stdout('2\n3\n4\n5\n6\n7\n8\n')

    #4.2 delete_node AC : 

    #B1P1C1
    def test_delete_node_when_node_is_leaf(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(1)
        self.assertIsNone(self.bst.root.left)
    
    #B1P1C2
    def test_delete_node_when_node_is_inner_with_left_child(self):
        self.bst.insert(3)
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 3)
        self.assertEqual(self.bst.root.left.value, 1)
    
    #B1P1C3
    def test_delete_node_when_node_is_inner_with_right_child(self):
        self.bst.insert(1)
        self.bst.insert(2)
        self.bst.insert(3)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 1)
        self.assertEqual(self.bst.root.right.value, 3)

    #B1P1C4
    def test_delete_node_when_node_is_inner_with_two_children(self):
        self.bst.insert(1)
        self.bst.insert(3)
        self.bst.insert(2)
        self.bst.insert(4)
        self.bst.delete_value(3)
        self.assertEqual(self.bst.root.value, 1)
        self.assertEqual(self.bst.root.right.value, 4)
        self.assertEqual(self.bst.root.right.left.value, 2)
    
    #B1P2C1
    def test_delete_node_when_node_is_root_with_no_children(self):
        self.bst.insert(1)
        self.bst.delete_value(1)
        self.assertIsNone(self.bst.root)
    
    #B1P2C2
    def test_delete_node_when_node_is_root_with_left_child(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 1)

    #B1P2C3
    def test_delete_node_when_node_is_root_with_right_child(self):
        self.bst.insert(2)
        self.bst.insert(3)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 3)
    
    #B1P2C4
    def test_delete_node_when_node_is_root_with_two_children(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.insert(3)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 3)
        self.assertEqual(self.bst.root.left.value, 1)

    # B2
    def test_delete_node_returns_None_when_BST_is_not_empty_and_delete_a_node_outside_the_BST(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.insert(3)
        self.assertIsNone(self.bst.delete_value(4))
        self.assertEqual(self.bst.root.value, 2)
        self.assertEqual(self.bst.root.left.value, 1)
        self.assertEqual(self.bst.root.right.value, 3)
    
    # B3
    def test_delete_node_returns_none_when_BST_is_empty(self):
        self.assertIsNone(self.bst.delete_value(1))

    #4.3 delete_node all-P-uses/some-C-uses : 
    
    # DEF(node) -> P(node == None)
    def test_p_delete_node_returns_none_if_passed_node_is_none(self):
        self.assertIsNone(self.bst.delete_node(None))

    # DEF(node) -> P(self.search(node.value) == None)
    def test_p_delete_node_returns_none_if_passed_node_value_is_none(self):
        self.assertIsNone(self.bst.delete_node(node()))
    
    # DEF(node_parent) -> !P(node_parent is not None) CASE1
    def test_p_delete_node_when_node_is_childless_root(self):
        self.bst.insert(1)
        self.bst.delete_value(1)
        self.assertIsNone(self.bst.root)
    
    # DEF(node_parent) -> P(node_parent.left == node) CASE1
    def test_p_delete_node_when_node_to_delete_is_a_left_child_and_childless(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(1)
        self.assertIsNone(self.bst.root.left)
    
    # DEF(node_parent) -> !P(node_parent.left == node) CASE1
    def test_p_delete_node_when_node_to_delete_is_a_right_child_and_childless(self):
        self.bst.insert(2)
        self.bst.insert(3)
        self.bst.delete_value(3)
        self.assertIsNone(self.bst.root.right)

    # DEF(node_parent) -> !P(node_parent is not None) CASE2
    def test_p_delete_node_when_node_to_delete_is_root_and_has_one_child(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 1)
    
    # DEF(node_parent) -> P(node_parent.left == node) CASE2
    def test_p_delete_node_when_node_to_delete_is_a_left_child_and_has_one_child(self):
        self.bst.insert(3)
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.left.value, 1)
    
    # DEF(node_parent) -> !P(node_parent.left == node) CASE2
    def test_p_delete_node_when_node_to_delete_is_a_right_child_and_has_one_child(self):
        self.bst.insert(2)
        self.bst.insert(4)
        self.bst.insert(3)
        self.bst.delete_value(4)
        self.assertEqual(self.bst.root.right.value, 3)
    
    # DEF(node_children) -> P(node_children == 2) CASE3
    def test_p_delete_node_when_node_to_delete_has_two_children(self):
        self.bst.insert(3)
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(3)
        self.assertEqual(self.bst.root.value, 2)
        self.assertEqual(self.bst.root.left.value, 1)
    
    # DEF(node) -> P(node.left is not None) CASE2
    def test_p_delete_node_when_node_to_delete_has_left_child(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 1)
    
    # DEF(node) -> !P(node.left is not None) CASE2
    def test_p_delete_node_when_node_to_delete_has_right_child(self):
        self.bst.insert(2)
        self.bst.insert(3)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 3)
    
    # In sub-function min_value_node(n): DEF(current) -> !P(current.left is not None) CASE3
    def test_p_delete_node_when_node_to_delete_has_two_children_and_right_has_no_children(self):
        self.bst.insert(3)
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.delete_value(3)
        self.assertEqual(self.bst.root.value, 2)
        self.assertEqual(self.bst.root.left.value, 1)
    
    # In sub-function min_value_node(n): DEF(current) -> P(current.left is not None) CASE3
    def test_p_delete_node_when_node_to_delete_has_two_children_and_right_has_a_left_child(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.insert(4)
        self.bst.insert(3)
        self.bst.delete_value(2)
        self.assertEqual(self.bst.root.value, 3)
    
    # DEF(successor) -> C(self.delete_node(successor)) CASE3
    def test_p_delete_node_properly_handles_successor_deletion(self):
        self.bst.insert(1)
        self.bst.insert(4)
        self.bst.insert(3)
        self.bst.insert(6)
        self.bst.insert(5)
        self.bst.delete_value(4)
        self.assertEqual(self.bst.root.right.value, 5)
        self.assertIsNone(self.bst.root.right.right.left)

    #4.4 reverse

    # In reversetree(self): DEF(self) -> !P(self.root is not None)
    def test_reverse_when_no_root_then_reverse_returns_none(self):
        self.assertIsNone(self.bst.reversetree())
    
    # In reversetree(self): DEF(self) -> P(self.root is not None)
    def test_reverse_when_root_present_then_reverse_does_not_return_none(self):
        self.bst.insert(1)
        self.assertIsNotNone(self.bst.reversetree())

    # In _reversetree(self, cur_node): DEF(cur_node) -> !P(cur_node is None) but root.left and root.right are None
    def test_reverse_when_only_root_present_then_tree_does_not_change(self):
        self.bst.insert(1)
        self.bst.reversetree()
        self.assertEqual(self.bst.root.value, 1)
    
    # In _reversetree(self, cur_node): DEF(cur_node) -> P(cur_node is None)
    def test_private_reverse_when_cur_node_is_none(self):
        self.assertIsNone(self.bst._reversetree(None))
    
    # In _reversetree(self, cur_node): DEF(cur_node.right) -> C(self._reversetree(cur_node.right))
    def test_reverse_when_root_has_left_child_it_becomes_right_child(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.reversetree()
        self.assertEqual(self.bst.root.value, 2)
        self.assertIsNone(self.bst.root.left)
        self.assertEqual(self.bst.root.right.value, 1)
    
    # In _reversetree(self, cur_node): DEF(cur_node.left) -> C(self._reversetree(cur_node.left))
    def test_reverse_when_root_has_right_child_it_becomes_left_child(self):
        self.bst.insert(2)
        self.bst.insert(3)
        self.bst.reversetree()
        self.assertEqual(self.bst.root.value, 2)
        self.assertEqual(self.bst.root.left.value, 3)
        self.assertIsNone(self.bst.root.right)
    
    # In _reversetree(self, cur_node): DEF(cur_node.left, cur_node.right) -> C(self._reversetree(cur_node.left))
    #                                                                     -> C(self._reversetree(cur_node.right))
    def test_reverse_when_root_has_two_children_on_both_sides_they_become_inverted(self):
        self.bst.insert(2)
        self.bst.insert(1)
        self.bst.insert(3)
        self.bst.reversetree()
        self.assertEqual(self.bst.root.value, 2)
        self.assertEqual(self.bst.root.right.value, 1)
        self.assertEqual(self.bst.root.left.value, 3)

if __name__ == '__main__':
    unittest.main()

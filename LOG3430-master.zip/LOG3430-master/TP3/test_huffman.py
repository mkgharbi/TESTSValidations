import unittest
from huffman import *

class TestHuffman(unittest.TestCase):
    #Pour ces tests, nous utiliserons "abcaba" comme string de reference
    
    def setUp(self):
        self.huff_ref = Huffman(6,"acb",Huffman(3,"a"),Huffman(3,"cb",Huffman(1,"c"),Huffman(2,"b")))

    #Tests rapporteur
    def test_build_codebook_return(self):
        huff1 = Huffman(3,"a")
        self.assertEqual(huff1.build_codebook(), {})

        huff2 = Huffman(3,"a", Huffman(3, "a"))
        self.assertEqual(huff2.build_codebook(), {'a': '0'})

        self.assertEqual(self.huff_ref.build_codebook(), {'a': '0', 'c': '10', 'b': '11'})
    
    #Tests constructeurs

    def test_init_constructs_correctly(self):
        huff1 = Huffman(3,"a")
        self.assertEqual(huff1.weight, 3)
        self.assertEqual(huff1.data, "a")
        self.assertIsNone(huff1.left)
        self.assertIsNone(huff1.right)
        self.assertEqual(huff1.codebook,{})

        huff2 = Huffman(3,"a", Huffman(3, "a"))
        self.assertEqual(huff2.weight, 3)
        self.assertEqual(huff2.data, "a")
        self.assertIsInstance(huff2.left, Huffman)
        self.assertEqual(huff2.left.weight, 3)
        self.assertEqual(huff2.left.data, "a")
        self.assertIsNone(huff2.right)
        self.assertEqual(huff2.codebook,{'a': '0'})

        self.assertEqual(self.huff_ref.weight, 6)
        self.assertEqual(self.huff_ref.data, "acb")
        self.assertIsInstance(self.huff_ref.left, Huffman)
        self.assertEqual(self.huff_ref.left.weight, 3)
        self.assertEqual(self.huff_ref.left.data, "a")
        self.assertIsInstance(self.huff_ref.right, Huffman)
        self.assertEqual(self.huff_ref.right.weight, 3)
        self.assertEqual(self.huff_ref.right.data, "cb")
        self.assertEqual(self.huff_ref.codebook,{'a': '0', 'c': '10', 'b': '11'})
    
    #Tests Transformateurs

    def test_build_codebook_transformation(self):
        self.huff_ref.codebook = {}
        self.huff_ref.build_codebook()
        self.assertEqual(self.huff_ref.codebook,{'a': '0', 'c': '10', 'b': '11'})
    
    #Tests Autres

    def test_eq(self):
        huff2 = Huffman(6,"acb",Huffman(3,"a"),Huffman(3,"cb",Huffman(1,"c"),Huffman(2,"b")))
        self.assertTrue(self.huff_ref.__eq__(huff2))

        #aabcaba
        huff3 = Huffman(7,"acb",Huffman(4,"a"),Huffman(3,"cb",Huffman(1,"c"),Huffman(2,"b")))
        self.assertFalse(self.huff_ref.__eq__(huff3))
    
    def test_lt(self):
        huff2 = Huffman(6,"acb",Huffman(3,"a"),Huffman(3,"cb",Huffman(1,"c"),Huffman(2,"b")))
        self.assertFalse(self.huff_ref.__lt__(huff2))

        #aabcaba
        huff3 = Huffman(7,"acb",Huffman(4,"a"),Huffman(3,"cb",Huffman(1,"c"),Huffman(2,"b")))
        self.assertTrue(self.huff_ref.__lt__(huff3))

        #0bc0b0
        huff4 = Huffman(6,"0cb",Huffman(3,"0"),Huffman(3,"cb",Huffman(1,"c"),Huffman(2,"b")))
        self.assertFalse(self.huff_ref.__lt__(huff4))
    
    def test_repr(self):
        self.assertEqual(self.huff_ref.__repr__(),"<Huffman(data: acb, left: a, right: cb)>")
        self.assertEqual(self.huff_ref.left.__repr__(),"<Huffman(data: a, left: None, right: None)>")
        self.assertEqual(self.huff_ref.right.__repr__(),"<Huffman(data: cb, left: c, right: b)>")
    
    def test_is_leaf(self):
        self.assertFalse(self.huff_ref.is_leaf())
        self.assertTrue(self.huff_ref.left.is_leaf())
        self.assertFalse(self.huff_ref.right.is_leaf())
        self.assertTrue(self.huff_ref.right.left.is_leaf())
        self.assertTrue(self.huff_ref.right.right.is_leaf())
    
    def test_encode_tree(self):
        encoded,leaves = self.huff_ref.encode_tree()
        #a = 0, b = 11, c = 10
        self.assertEqual(encoded,"01011")
        self.assertEqual(leaves, "acb")
    
    def test_huffman_encode(self):
        #a = 0, b = 11, c = 10
        self.assertEqual(self.huff_ref.huffman_encode("abcaba"), "011100110")
    
    #-----Tests pour coverage manquant--------#

    def test_huffman_decode_composed_string(self):
        encoded = self.huff_ref.huffman_encode("abcaba")
        self.assertEqual(self.huff_ref.huffman_decode(encoded), "abcaba")

    def test_huffman_decode_raises_value_excpetion(self):
        with self.assertRaises(ValueError):
            unzipped = self.huff_ref.huffman_decode("012")

    def test_huffman_from_string_when_empty_string_is_passed_raises_index_error(self):
        with self.assertRaises(IndexError):
            Huffman.from_string("")
    
    # Cas: On ne rentre pas dans la boucle while
    def test_huffman_from_string_when_single_char_string_is_passed(self):
        huff = Huffman.from_string("aaa")
        self.assertEqual(huff.__repr__(), "<Huffman(data: a, left: None, right: None)>")
        self.assertEqual(huff.codebook, {})
    
    # Cas: On rentre dans la boucle while
    def test_huffman_from_string_when_regular_string_is_passed(self):
        huff = Huffman.from_string("abcaba")
        self.assertEqual(huff.__repr__(), "<Huffman(data: acb, left: a, right: cb)>")
    
    def test_huffman_zip_function(self):
        self.assertNotEqual(Huffman.zip("abcaba"), "abcaba")
    
    def test_huffman_unzip_function(self):
        zipped = Huffman.zip("abcaba")
        self.assertEqual(Huffman.unzip(zipped), "abcaba")
    
    def test_huffman_unzip_raises_value_exception(self):
        with self.assertRaises(ValueError):
            Huffman.unzip("wrong")


    def test_zip_function(self):
        self.assertNotEqual(zip("abcaba"), "abcaba")
    
    def test_unzip_function(self):
        zipped = zip("abcaba")
        self.assertEqual(unzip(zipped), "abcaba")
        
    def test_compress_binary(self):
        toCompessString = "100011"
        resultChar, pad = compress_binary_string(toCompessString)
        self.assertEqual(resultChar, '#')
        self.assertEqual(pad, 2)

    def test_expand_compressed(self):
        toExpandString = "#"
        resultChar = expand_compressed_string(toExpandString, 2)
        self.assertEqual(resultChar, '100011')


    def test_unzip_tree_returns_None(self):
        self.assertEqual(Huffman.unzip_tree('', [], 2), None)

    def test_unzip_tree(self):
        resultChar = compress_binary_string(toExpandString)
        self.assertEqual(resultChar, '100011')
    


    #Tests cas extremes

    def test_collectionStrings(self):
        collectionStrings = [
            'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
            'XXXX-XXXX-XXXX-XXXX',
            '*KWxx5byy12hri3l3lKRAB',
            '18NPLdeep',
            'Gssssssssss111111111111111****************',
            'AAAAAAAAAAAAAAAAAAAACCCCCCCCCCCCCCCCCBBBBBBBBBBBBBB',
            'QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ',
            '\n{a-9}~\\x^&`<>^^2*_MM|grep@||'
        ]
        zipped = Huffman.zip(collectionStrings[0])
        self.assertEqual(Huffman.unzip(zipped), "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        zipped = Huffman.zip(collectionStrings[1])
        self.assertEqual(Huffman.unzip(zipped), "XXXX-XXXX-XXXX-XXXX")
        zipped = Huffman.zip(collectionStrings[2])
        self.assertEqual(Huffman.unzip(zipped), "*KWxx5byy12hri3l3lKRAB")
        zipped = Huffman.zip(collectionStrings[3])
        self.assertEqual(Huffman.unzip(zipped), "18NPLdeep")
        zipped = Huffman.zip(collectionStrings[4])
        self.assertEqual(Huffman.unzip(zipped), "Gssssssssss111111111111111****************")
        zipped = Huffman.zip(collectionStrings[5])
        self.assertEqual(Huffman.unzip(zipped), "AAAAAAAAAAAAAAAAAAAACCCCCCCCCCCCCCCCCBBBBBBBBBBBBBB")
        zipped = Huffman.zip(collectionStrings[7])
        self.assertEqual(Huffman.unzip(zipped), "\n{a-9}~\\x^&`<>^^2*_MM|grep@||")

        #On considere que dans le cadre de ce TP que l'exception est desirable
        with self.assertRaises(KeyError):
            zipped = Huffman.zip(collectionStrings[6])

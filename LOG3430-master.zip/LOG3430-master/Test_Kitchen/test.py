import pytest
import calcul

def test_add():
    assert calcul.add(2,2) == 4

def test_sub():
    assert calcul.sub(2,2) == 0

def test_mult():
    assert calcul.mult(2,2) == 4

def test_div():
    assert calcul.div(2,2) == 1

def test_div_zero():
    assert calcul.div(2,0) == ZeroDivisionError

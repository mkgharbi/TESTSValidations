import sqlite3
import os
import unittest
from unittest.mock import Mock
from models import Contact
from DAOs import ContactDAO


class TestContactDAO(unittest.TestCase):

    def setUp(self):
        self.db_file = 'temp.db'
        self.contactDAO = ContactDAO(self.db_file)
        self.contactDAO.init_db()

    def tearDown(self):
        os.remove(self.db_file)

    def test_when_init_db_is_called_it_should_create_table(self):
        try:
            with sqlite3.connect(self.db_file) as connection:
                cursor = connection.cursor()
                cursor.execute('SELECT * FROM contact')
        except sqlite3.OperationalError:
            self.fail("Should not have raised sqlite3.OperationalError")

    def test_when_add_is_called_it_should_return_an_auto_incremented_id(self):
        for index in range(1, 5):
            contact = Contact(101, "Name"+str(index), "lastName" +
                            str(index), 100+index, "mail"+str(index), True, 132.123)
            self.assertEqual(self.contactDAO.add(contact), index)

    def test_get_by_id_after_add_should_return_inserted_value(self):
        contact = Contact(100, "Sam", "Larry", "5467894562",
                        "mail@gmail.com", True, 123)
        idContact = self.contactDAO.add(contact)
        self.assertEqual(self.contactDAO.get_by_id(
            idContact).first_name, "Sam")
        self.assertEqual(self.contactDAO.get_by_id(
            idContact).last_name, "Larry")
        self.assertEqual(self.contactDAO.get_by_id(
            idContact).phone, '5467894562')
        self.assertEqual(self.contactDAO.get_by_id(
            idContact).mail, "mail@gmail.com")
        self.assertTrue(self.contactDAO.get_by_id(idContact).updated)
        self.assertEqual(self.contactDAO.get_by_id(
            idContact).updated_date, 123)

    def test_get_by_names_after_add_should_return_inserted_value(self):
        contact = Contact(100, "Sam", "Larry", "5467894562",
                        "mail@gmail.com", True, 123)
        idContact = self.contactDAO.add(contact)
        self.assertEqual(self.contactDAO.get_by_names(
            "Sam", "Larry").first_name, "Sam")
        self.assertEqual(self.contactDAO.get_by_names(
            "Sam", "Larry").last_name, "Larry")
        self.assertEqual(self.contactDAO.get_by_names(
            "Sam", "Larry").phone, '5467894562')
        self.assertEqual(self.contactDAO.get_by_names(
            "Sam", "Larry").mail, "mail@gmail.com")
        self.assertTrue(self.contactDAO.get_by_names("Sam", "Larry").updated)
        self.assertEqual(self.contactDAO.get_by_names(
            "Sam", "Larry").updated_date, 123)

    def test_get_by_id_with_undefined_rowid_should_return_None(self):
        self.assertEqual(self.contactDAO.get_by_id(1), None)

    def test_get_by_names_with_not_existed_contact_should_return_None(self):
        self.assertEqual(self.contactDAO.get_by_names(
            "Name", "OtherName"), None)

    def test_deactivate_contact_then_get_it_with_id_should_be_not_updated(self):
        contact = Contact(0, "Moez", "BC", "5556456456",
                        "mail@gmail.com", True, 123456)
        idContact = self.contactDAO.add(contact)
        self.contactDAO.deactivate(idContact)
        self.assertFalse(self.contactDAO.get_by_id(idContact).updated)

    def test_deactivate_contact_on_undefined_id_should_return_zero(self):
        self.assertEqual(self.contactDAO.deactivate(1), 0)

    def test_after_deleting_contact_by_id_get_it_with_id_should_return_None(self):
        contact = Contact(0, "Xavier", "Barachet",
                        "5468794563", "mail@gmail.com", True, 12345)
        idContact = self.contactDAO.add(contact)
        self.contactDAO.delete_by_id(idContact)
        self.assertEqual(self.contactDAO.get_by_id(idContact), None)

    def test_deleting_undefined_id_should_return_zero(self):
        self.assertEqual(self.contactDAO.delete_by_id(0), 0)

    def test_after_deleting_contact_by_names_get_item_with_id_should_return_None(self):
        contact = Contact(0, "Xavier", "Barachet",
                        "5468794563", "mail@gmail.com", True, 12345)
        idContact = self.contactDAO.add(contact)
        self.contactDAO.delete_by_names("Xavier", "Barachet")
        self.assertEqual(self.contactDAO.get_by_id(idContact), None)

    def test_deleting_not_existed_contact_should_return_zero(self):
        self.assertEqual(self.contactDAO.delete_by_names(
            "Youssef", "Bleili"), 0)

    def test_update_contact_should_set_the_provided_values(self):
        contactToAdd = Contact(101, "Samir", "Karabatic",
                            "5467894561", "mail@mail.com", True, 123.12)
        idContactToAdd = self.contactDAO.add(contactToAdd)
        contactToUpdate = Contact(
            idContactToAdd, "Xavier", "Barachet", "5468794563", "mail@gmail.com", True, 12345)
        count = self.contactDAO.update(contactToUpdate)
        self.assertEqual(self.contactDAO.get_by_id(
            idContactToAdd).first_name, "Xavier")
        self.assertEqual(self.contactDAO.get_by_id(
            idContactToAdd).last_name, "Barachet")
        self.assertEqual(self.contactDAO.get_by_id(
            idContactToAdd).phone, '5468794563')
        self.assertEqual(self.contactDAO.get_by_id(
            idContactToAdd).mail, "mail@gmail.com")
        self.assertTrue(self.contactDAO.get_by_id(idContactToAdd).updated)
        self.assertEqual(self.contactDAO.get_by_id(
            idContactToAdd).updated_date, 12345)

    def test_update_contact_should_return_zero_if_id_does_not_exist(self):
        contactToAdd1 = Contact(101, "Samir", "Karabatic",
                                "5467894561", "mail@mail.com", True, 123.12)
        contactToAdd2 = Contact(
            102, "Samir1", "Karabatic1", "5467894560", "mail1@mail.com", True, 123.12)
        contactToAdd3 = Contact(
            103, "Samir2", "Karabatic2", "5467894562", "mail2@mail.com", True, 123.12)
        self.assertEqual(self.contactDAO.update(contactToAdd1), 0)
        self.assertEqual(self.contactDAO.update(contactToAdd2), 0)
        self.assertEqual(self.contactDAO.update(contactToAdd3), 0)

    def test_list_contacts_with_no_contacts_added_returns_empty_list(self):
        self.assertEqual(self.contactDAO.list(), [])
        self.assertEqual(self.contactDAO.list(False), [])
        self.assertEqual(self.contactDAO.list(True), [])

    def test_list_contacts_with_one_contact_should_return_list_with_contact(self):
        contactToAdd = Contact(101, "Samir", "Karabatic",
                            "5467894561", "mail@mail.com", True, 123.12)
        idContact = self.contactDAO.add(contactToAdd)
        self.assertEqual(len(self.contactDAO.list()), 1)
        self.assertEqual(self.contactDAO.list()[0].first_name, "Samir")
        self.assertEqual(self.contactDAO.list()[0].last_name, "Karabatic")
        self.assertEqual(self.contactDAO.list()[0].phone, "5467894561")
        self.assertEqual(self.contactDAO.list()[0].mail, "mail@mail.com")
        self.assertTrue(self.contactDAO.list()[0].updated)
        self.assertEqual(self.contactDAO.list()[0].updated_date, 123.12)

    def test_list_contacts_with_updated_False_and_all_items_updated_should_return_empty_list(self):
        for index in range(1, 5):
            contactToAdded = Contact(101, "John"+str(index), "Zitouni"+str(index),
                                    "456-489-7563", "myEmail@gmail.com" +
                                    str(index),
                                    True, 123456.12345)
            idContact = self.contactDAO.add(contactToAdded)
        self.assertEqual(self.contactDAO.list(False), [])

    def test_list_contacts_with_updated_True_and_all_items_not_updated_should_return_empty_list(self):
        for index in range(1, 5):
            contactToAdded = Contact(101, "John"+str(index), "Zitouni"+str(index),
                                    "456-489-7563", "myEmail@gmail.com" +
                                    str(index),
                                    False, 123456.12345)
            idContact = self.contactDAO.add(contactToAdded)
        self.assertEqual(self.contactDAO.list(True), [])

    def test_list_contacts_with_all_not_updated_items_and_updated_False_should_return_all_contacts(self):
        for index in range(1, 5):
            contactToAdded = Contact(101, "John"+str(index), "Zitouni"+str(index),
                                    "456-489-7563", "myEmail@gmail.com" +
                                    str(index),
                                    False, 123456.12345)
            idContact = self.contactDAO.add(contactToAdded)
        self.assertEqual(len(self.contactDAO.list(False)), 4)

    def test_list_contacts_with_all_updated_items_and_updated_True_should_return_all_contacts(self):
        for index in range(1, 5):
            contactToAdded = Contact(101, "John"+str(index), "Zitouni"+str(index),
                                    "456-489-7563", "myEmail@gmail.com" +
                                    str(index),
                                    True, 123456.12345)
            idContact = self.contactDAO.add(contactToAdded)
        self.assertEqual(len(self.contactDAO.list(True)), 4)


if __name__ == '__main__':
    unittest.main()

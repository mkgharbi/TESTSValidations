import unittest
from models import Contact

class TestContact(unittest.TestCase):
    def test_mail(self):
        self.cont_1 = Contact(1, 'Noureddine', 'Kerzazi', 4444444444)
        self.cont_2 = Contact(2, 'Bram', 'Adam', 4444444445)

        self.assertEqual(self.cont_1.mail, 'Noureddine.Kerzazi@polymtl.ca')
        self.assertEqual(self.cont_2.mail, 'Bram.Adam@polymtl.ca')

        self.cont_1.first_name = 'Noureddine2'
        self.cont_2.first_name = 'Bram2'
        self.assertEqual(self.cont_1.mail, 'Noureddine2.Kerzazi@polymtl.ca')
        self.assertEqual(self.cont_2.mail, 'Bram2.Adam@polymtl.ca')

    def test_full_name(self):
        self.cont_1 = Contact(1, 'Noureddine', 'Kerzazi', 4444444444)
        self.cont_2 = Contact(2, 'Bram', 'Adam', 4444444445)

        self.assertEqual(self.cont_1.full_name, 'Noureddine Kerzazi')
        self.assertEqual(self.cont_2.full_name, 'Bram Adam')
        self.cont_1.first_name = 'Noureddine2'
        self.cont_2.first_name = 'Bram2'
        self.assertEqual(self.cont_1.full_name, 'Noureddine2 Kerzazi')
        self.assertEqual(self.cont_2.full_name, 'Bram2 Adam')
        
    def test_apply_raise(self):
        self.cont_1 = Contact(1, 'Noureddine', 'Kerzazi', "4444444444", "test@test.ca", False, "1/1/1971", 50000)
        self.cont_2 = Contact(2, 'Bram', 'Adam', "4444444445", "test2@test.ca", False, "1/1/1971", 60000)
        self.cont_1.apply_raise()
        self.cont_2.apply_raise()
        self.assertEqual(self.cont_1.pay, 52500)
        self.assertEqual(self.cont_2.pay, 63000)

if __name__ == '__main__':
    unittest.main()

import sqlite3
import unittest
from unittest.mock import Mock
import os
from models import Contact
from DAOs import ContactDAO
from services import ContactService, AlreadyExistedItem, UndefinedID, NotExistedItem, InvalidPhoneNumber, InvalidMailAddress
from datetime import datetime
# To complete...
class TestContactService(unittest.TestCase):

    def setUp(self):
        self.contactDAO = Mock()
        self.contactService = ContactService(self.contactDAO)
    
    def test_when_contact_is_created_updated_should_be_True(self):
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        contact = self.contactService.create_contact('Houssem','Ben Braiek','123-456-7891','houssem.bb@gmail.com')
        self.assertTrue(contact.updated)
    
    def test_when_contact_is_created_updated_date_should_be_now(self):
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        contact = self.contactService.create_contact(
            'Houssem', 'Ben Braiek', '123-456-7891', 'houssem.bb@gmail.com')
        self.assertAlmostEqual(contact.updated_date,
                                datetime.now().timestamp())

    def test_when_contact_is_created_and_DAO_get_by_names_returns_contact_it_should_raise_AlreadyExistedItem(self):
        self.contactDAO.get_by_names.return_value = Contact(101,'Houssem', 'Ben Braiek', '123-456-7891',
                                                            'houssem.bb@gmail.com', True, 1234)
        self.assertRaises(AlreadyExistedItem, self.contactService.create_contact,
                            'Houssem', 'Ben Braiek', '123-456-7891', 'houssem.bb@gmail.com')

    
    def test_when_contact_is_changed_updated_should_be_True(self):
        self.contactDAO.update.return_value = 1
        contact = self.contactService.update_contact(101, 'Houssem', 'Ben Braiek', '123-456-7891', 'houssem.bb@gmail.com')
        self.assertTrue(contact.updated)
    
    def test_when_contact_is_changed_updated_date_should_be_now(self):
        self.contactDAO.update.return_value = 1
        contact = self.contactService.update_contact(101, 'Houssem', 'Ben Braiek', '123-456-7891', 'houssem.bb@gmail.com')
        self.assertAlmostEqual(contact.updated_date,
                                datetime.now().timestamp())

    def test_when_contact_is_changed_and_DAO_update_returns_zero_it_should_raise_UndefinedID(self):
        self.contactDAO.update.return_value = 0
        self.assertRaises(UndefinedID, self.contactService.update_contact,
                            101, 'Houssem', 'Ben Braiek', '123-456-7891', 'houssem.bb@gmail.com')

    def test_when_retrieve_contact_is_called_with_id_and_DAO_get_by_id_should_be_called(self):
        contact = Contact(101, "Houssem", "Ben Braiek",
                            '123-456-7891', "houssem.bb@gmail.com", True, 123456.123)
        self.contactDAO.get_by_id.return_value = contact
        self.assertEqual(self.contactService.retrieve_contact(1), contact)
        self.assertTrue(self.contactDAO.get_by_id.called)
    
    def test_when_retrieve_contact_is_called_with_names_and_DAO_get_by_names_should_be_called(self):
        contact = Contact(101, "Houssem", "Ben Braiek",
                            '123-456-7891', "houssem.bb@gmail.com", True, 123456.123)
        self.contactDAO.get_by_names.return_value = contact
        self.assertEqual(self.contactService.retrieve_contact(
            None, 'Houssem', 'Ben Braiek'), contact)
        self.assertTrue(self.contactDAO.get_by_names.called)


    def test_when_retrieve_contact_is_called_with_id_and_DAO_returns_None_it_should_raise_UndefinedID(self):
        self.contactDAO.get_by_id.return_value = None
        self.assertRaises(UndefinedID, self.contactService.retrieve_contact, 1)
    
    def test_when_retrieve_contact_is_called_with_names_and_DAO_returns_None_it_should_raise_NotExistedItem(self):
        self.contactDAO.get_by_names.return_value = None
        self.assertRaises(NotExistedItem, self.contactService.retrieve_contact, None, 'Sadio', 'Mane')

    def test_when_delete_contact_is_called_with_id_and_DAO_delete_by_id_should_be_called(self):
        self.contactDAO.delete_by_id.return_value = 1
        self.contactService.delete_contact(1)
        self.assertTrue(self.contactDAO.delete_by_id.called)
    
    def test_when_delete_contact_is_called_with_names_and_DAO_delete_by_names_should_be_called(self):
        self.contactDAO.delete_by_id.return_value = 1
        self.contactService.delete_contact(None, "Sadio", "Mane")
        self.assertTrue(self.contactDAO.delete_by_names.called)

    def test_when_delete_contact_is_called_with_id_and_DAO_delete_by_id_returns_zero_it_should_raise_UndefinedID(self):
        self.contactDAO.delete_by_id.return_value = 0
        self.assertRaises(UndefinedID, self.contactService.delete_contact, 1)
    
    def test_when_retrieve_contact_is_called_with_names_and_DAO_delete_by_names_returns_zero_it_should_raise_NotExistedItem(self):
        self.contactDAO.delete_by_names.return_value = 0
        self.assertRaises(
            NotExistedItem, self.contactService.delete_contact, None, "Sadio", "Mane")
    
    def test_active_contact_is_not_deactivated(self):
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        contact = self.contactService.create_contact('Houssem','Ben Braiek','123-456-7891','houssem.bb@gmail.com')
        self.contactDAO.list.return_value = [contact]
        self.contactService.verify_contacts_status()
        self.assertFalse(self.contactDAO.deactivate.called)
    
    def test_inactive_contact_is_deactivated(self):
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        contact = self.contactService.create_contact('Houssem','Ben Braiek','123-456-7891','houssem.bb@gmail.com')
        # 1097 jours = 94780800 secondes
        contact.updated_date = contact.updated_date - 94780800
        self.contactDAO.list.return_value = [contact]
        self.contactService.verify_contacts_status()
        self.assertTrue(self.contactDAO.deactivate.called)
    
    def test_deactivated_not_called_when_no_contact_in_list(self):
        self.contactDAO.list.return_value = []
        self.contactService.verify_contacts_status()
        self.assertFalse(self.contactDAO.deactivate.called)

    def test_check_phone_identifies_valid_numbers(self):
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        contact1 = self.contactService.create_contact('Houssem', 'Ben Braiek', '1234567891', 'houssem.bb@gmail.com')
        contact2 = self.contactService.create_contact('Houssem1', 'Ben Braiek1', '123-456-7890', 'houssem1.bb1@gmail.com')
        contact3 = self.contactService.create_contact('Houssem2', 'Ben Braiek2', '(123)-456-7891', 'houssem2.bb2@gmail.com')
        self.assertTrue(self.contactService.check_phone(contact1.phone))
        self.assertTrue(self.contactService.check_phone(contact2.phone))
        self.assertTrue(self.contactService.check_phone(contact3.phone))

    def test_check_phone_identifies_invalid_numbers(self):
        self.assertFalse(self.contactService.check_phone("12345"))
        self.assertFalse(self.contactService.check_phone("123-4567890"))
        self.assertFalse(self.contactService.check_phone("(123-456-7890"))
        self.assertFalse(self.contactService.check_phone(""))
    
    def test_create_contact_raises_invalid_phone_number_exception(self):
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        self.assertRaises(InvalidPhoneNumber, self.contactService.create_contact, 
        'Houssem', 'Ben Braiek', '123456', 'houssem.bb@gmail.com')
    
    def test_update_contact_raises_invalid_phone_number_exception(self):
        self.contactDAO.update.return_value = 1
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        contact1 = self.contactService.create_contact('Houssem', 'Ben Braiek', '1234567891', 'houssem.bb@gmail.com')
        self.assertRaises(InvalidPhoneNumber, self.contactService.update_contact, 
        contact1.id, contact1.first_name, contact1.last_name, '123456', contact1.mail)

    def test_check_mail_identifies_valid_emails(self):
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        contact1 = self.contactService.create_contact('Houssem', 'Ben Braiek', '1234567891', 'houssem.bb@gmail.com')
        self.assertTrue(self.contactService.check_mail(contact1.mail))

    def test_check_mail_identifies_invalid_emails(self):
        self.assertFalse(self.contactService.check_mail("houssem.bbgmail.com"))
        self.assertFalse(self.contactService.check_mail("houssem.bb@gmail"))
        self.assertFalse(self.contactService.check_mail("houssem.bb@gmail."))
        self.assertFalse(self.contactService.check_mail("@gmail.com"))
        self.assertFalse(self.contactService.check_mail(""))
    
    def test_create_contact_raises_invalid_mail_number_exception(self):
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        self.assertRaises(InvalidMailAddress, self.contactService.create_contact, 
        'Houssem', 'Ben Braiek', '1234567890', 'houssem.bbgmail.com')
    
    def test_update_contact_raises_invalid_phone_mail_exception(self):
        self.contactDAO.update.return_value = 1
        self.contactDAO.add.return_value = 1
        self.contactDAO.get_by_names.return_value = None
        contact1 = self.contactService.create_contact('Houssem', 'Ben Braiek', '1234567891', 'houssem.bb@gmail.com')
        self.assertRaises(InvalidMailAddress, self.contactService.update_contact, 
        contact1.id, contact1.first_name, contact1.last_name, contact1.phone, 'houssem.bbgmail.com')

        
if __name__ == '__main__':
    unittest.main()
    

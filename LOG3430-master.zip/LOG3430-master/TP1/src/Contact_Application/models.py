from datetime import datetime


class Contact:

    def __init__(self, id, first_name, last_name, phone, mail=None, updated=False, updated_date=0, pay=50000):
        self.id = id
        self.first_name = first_name
        self.last_name = last_name
        self.phone = phone

        # Python standard way of defining a private attribute
        self.__mail = mail
         
        self.updated = bool(updated)
        self.updated_date = updated_date
        self.pay = pay
    
    # full_name automatiquement mis a jour quand first_name ou last_name mis a jour
    @property
    def full_name(self):
        return self.first_name + " " + self.last_name
    
    # mail automatiquement mis a jour quand first_name ou last_name mis a jour
    @property
    def mail(self):
        if self.__mail is None:
            return self.first_name + "." + self.last_name + "@polymtl.ca"
        else:
            return self.__mail

    def apply_raise(self):
        '''
        Augmente le salaire de 5%
        '''
        self.pay = self.pay*1.05
        
    def __str__(self):
        return '''{self.first_name} {self.last_name} has {self.phone} and {self.mail}.
        This information is updated on {}'''.format(datetime.fromtimestamp(self.updated_date), self=self)